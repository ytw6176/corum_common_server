#if !defined(AFX_STDAFX_H__72D057F3_855A_4E76_854A_C611E4EB3023__INCLUDED_)
#define AFX_STDAFX_H__72D057F3_855A_4E76_854A_C611E4EB3023__INCLUDED_


#if _MSC_VER > 1000
#pragma once
#endif 


#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0500


#include <WINSOCK2.H>
#include <WINDOWS.H>
#include <STDIO.H>
#include <STDLIB.H>
#include <TIME.H>


#pragma warning(disable : 4100) // ������ ���� �Լ� ���� ���


#endif 
