#pragma once

#ifdef SS3D_TEST
#include "./../SS3D_0719/4dyuchigx/4DyuchiGXGFunc/global.h"
#else
#include "./../4DyuchiGXGFunc/global.h"
#endif
#include "ItemManagerDefine.h"
#include "BaseItem.h"
#include "Item.h"
#include "ItemManager.h"

