#pragma once


#include "AbyssHash64.h"
#include "BaseItem.h"


typedef CAbyssHash<CBaseItem> BASEITEM_HASH,*LPBASEITEM_HASH;
