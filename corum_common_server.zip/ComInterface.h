#pragma once


#include "IOleDBThread.h"
#include "INetWork.h"
#include "CommonGlobalDefine.h"